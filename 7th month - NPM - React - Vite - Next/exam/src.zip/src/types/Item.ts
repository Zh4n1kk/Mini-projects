type Item = {
    name: string,
    price: any
    quantity: number    
}

export default Item